function dochange () {
  alert('dododo');
}